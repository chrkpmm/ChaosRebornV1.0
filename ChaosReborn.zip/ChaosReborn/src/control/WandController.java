package control;

public class WandController {
}
