package resources.constants;

public interface CreatureConstant {

}
