package resources.constants;

public interface CardConstant {
}
