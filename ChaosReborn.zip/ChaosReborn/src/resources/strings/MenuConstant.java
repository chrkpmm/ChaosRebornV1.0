package resources.strings;

public interface MenuConstant {
}
