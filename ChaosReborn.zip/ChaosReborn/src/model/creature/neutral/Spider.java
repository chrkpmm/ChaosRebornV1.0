package model.creature.neutral;

public class Spider {
}
