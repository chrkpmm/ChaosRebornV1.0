package model.creature.chaotic;

public class Skeleton {
}
