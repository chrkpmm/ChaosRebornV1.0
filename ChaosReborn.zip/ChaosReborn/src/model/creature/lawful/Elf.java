package model.creature.lawful;

public class Elf {
}
