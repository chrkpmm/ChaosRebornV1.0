package model.wand;

public abstract class Wand{
}
