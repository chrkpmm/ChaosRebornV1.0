package model.card;

public class Neutral extends Card {
}
