package model.card;

public abstract class Card {
}
