package model.card;

public class Chaotic {
}
