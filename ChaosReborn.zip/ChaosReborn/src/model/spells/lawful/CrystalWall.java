package model.spells.lawful;

public class CrystalWall {
}
