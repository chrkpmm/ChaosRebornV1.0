package model.spells.neutral;

public class MegaBolt {
}
