package utility;

public class Logger {
    
    public static void view (String output)
    {
        System.out.print(output);
    }
    
}
